var ex_8c =
[
    [ "lmdif", "ex_8c.html#a925d0294cefdd80340e0fbe2aae2f78f", null ],
    [ "dpmpar", "ex_8c.html#a9fda434dc5844acf040123d4d2fab245", null ]
];