var main_8c =
[
    [ "main", "main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "residual", "main_8c.html#af1d89f41fce33f6942bfce8fb900b111", null ],
    [ "DATA_NUM", "main_8c.html#a34332033a7bbee04520f9cd24745a746", null ],
    [ "dpmpar", "main_8c.html#a9fda434dc5844acf040123d4d2fab245", null ],
    [ "dy", "main_8c.html#a1a08bc2ae101b190d4f2531295f0ef4a", null ],
    [ "ey", "main_8c.html#a0922945131a9922dbc91c382808f2e6c", null ],
    [ "fvecs", "main_8c.html#a16b247a382e2083c49330dc729671c19", null ],
    [ "infoes", "main_8c.html#a09d5e080b98066297afe9961897aade6", null ],
    [ "nfevs", "main_8c.html#aa4ee5d5746fe467ab3e8b0baa6755d64", null ],
    [ "PARA_NUM", "main_8c.html#ae1a27e192e29a518a04b4a00931f29ec", null ],
    [ "results", "main_8c.html#a777d7ae5dfdceb89b494dd5ebccd959b", null ],
    [ "test", "main_8c.html#a45ff32161e0bd1b967dfcdf99a90d1be", null ],
    [ "tols", "main_8c.html#aa967832bd3f39c0ced9780f7cb353d66", null ],
    [ "x", "main_8c.html#ae612c36027855379f09aa235ee31af61", null ],
    [ "x_changed", "main_8c.html#adc2da403cc4ecfab5ce72a7a080cc6ae", null ],
    [ "x_org", "main_8c.html#a370037f1323de0e77db546b7d3a51647", null ]
];