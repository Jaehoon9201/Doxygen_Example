var searchData=
[
  ['infoes_0',['infoes',['../main_8c.html#a09d5e080b98066297afe9961897aade6',1,'main.c']]],
  ['introduction_20of_20the_20project_20files_1',['Introduction of the project files',['../md__ex_code___subpage1__.html',1,'']]]
];
