var searchData=
[
  ['residual_0',['residual',['../main_8c.html#af1d89f41fce33f6942bfce8fb900b111',1,'main.c']]],
  ['results_1',['results',['../main_8c.html#a777d7ae5dfdceb89b494dd5ebccd959b',1,'main.c']]]
];
