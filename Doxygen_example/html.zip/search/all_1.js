var searchData=
[
  ['data_5fnum_0',['DATA_NUM',['../main_8c.html#a34332033a7bbee04520f9cd24745a746',1,'main.c']]],
  ['dpmpar_1',['dpmpar',['../ex_8c.html#a9fda434dc5844acf040123d4d2fab245',1,'dpmpar():&#160;main.c'],['../main_8c.html#a9fda434dc5844acf040123d4d2fab245',1,'dpmpar():&#160;main.c']]],
  ['dy_2',['dy',['../main_8c.html#a1a08bc2ae101b190d4f2531295f0ef4a',1,'main.c']]]
];
