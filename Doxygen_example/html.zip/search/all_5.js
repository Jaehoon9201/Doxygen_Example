var searchData=
[
  ['lmdif_0',['lmdif',['../ex_8c.html#a925d0294cefdd80340e0fbe2aae2f78f',1,'ex.c']]]
];
