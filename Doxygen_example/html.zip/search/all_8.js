var searchData=
[
  ['para_5fnum_0',['PARA_NUM',['../main_8c.html#ae1a27e192e29a518a04b4a00931f29ec',1,'main.c']]]
];
