var indexSectionsWithContent =
{
  0: "_defilmnprtx",
  1: "_em",
  2: "lmr",
  3: "definprtx",
  4: "ei"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

