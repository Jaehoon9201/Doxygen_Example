var searchData=
[
  ['x_0',['x',['../main_8c.html#ae612c36027855379f09aa235ee31af61',1,'main.c']]],
  ['x_5fchanged_1',['x_changed',['../main_8c.html#adc2da403cc4ecfab5ce72a7a080cc6ae',1,'main.c']]],
  ['x_5forg_2',['x_org',['../main_8c.html#a370037f1323de0e77db546b7d3a51647',1,'main.c']]]
];
